import os
print('water bot placeholder')
