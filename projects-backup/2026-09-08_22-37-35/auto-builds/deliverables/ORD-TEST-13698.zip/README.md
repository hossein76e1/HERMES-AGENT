# ربات یادآور آب

BOT_TOKEN را در .env بگذار و `python main.py` را اجرا کن.